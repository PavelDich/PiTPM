class Employee:
    name = "Jeb"
    surname = "Smith"
    age = 43
    salary = 2500

    def __init__(self):
        print(self.name, self.surname, self.age, self.salary)

employee = Employee()

