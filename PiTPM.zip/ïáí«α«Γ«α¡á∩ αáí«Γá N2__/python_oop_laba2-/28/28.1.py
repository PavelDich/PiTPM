class User:
    pass

class Employee(User):
    pass