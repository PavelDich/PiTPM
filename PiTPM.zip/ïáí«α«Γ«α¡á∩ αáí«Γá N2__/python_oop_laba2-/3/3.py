class Employee:
    name = "Jeb"
    age = 43
    salary = 2500

employee = Employee()
print(employee.name, employee.age, employee.salary)
