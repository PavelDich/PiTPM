Адаптированные практические задания для python

[code.mu](https://code.mu/ru/javascript/book/oop/)
