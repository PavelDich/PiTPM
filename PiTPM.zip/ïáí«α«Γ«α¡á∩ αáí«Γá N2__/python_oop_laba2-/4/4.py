class Employee:
    name = "Jeb"
    age = 43
    salary = 2500

employee1 = Employee()
employee1.name = "Ron"
employee1.age = 17
employee1.salary = 2300
employee2 = Employee()
employee2.name = "Jeramy"
employee2.age = 23
employee2.salary = 4200
employee3 = Employee()
employee3.name = "Mary"
employee3.age = 54
employee3.salary = 1700
print(employee1.name, employee1.age, employee1.salary)
print(employee2.name, employee2.age, employee2.salary)
print(employee3.name, employee3.age, employee3.salary)
