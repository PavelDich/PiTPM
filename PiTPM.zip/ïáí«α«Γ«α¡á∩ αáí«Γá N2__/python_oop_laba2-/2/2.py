class Employee:
    name = "Jeb"
    age = 43

employee = Employee()
print(employee)
